package main;

public interface PrintInfo {
    String getInformation();
}
